package admissionofficeproject;


import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;

public class WithDraw {

	private JFrame frame;
	private JTextField textField_1;
	private JTextField textField_2;


	public WithDraw() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1200, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Withdraw portal");
		frame.setVisible(true);
		frame.setResizable(false);
		
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(102, 205, 170));
		frame.getContentPane().add(panel_3, BorderLayout.NORTH);
		
		JLabel label_2 = new JLabel("Withdraw Course");
		label_2.setFont(new Font("Sitka Text", Font.BOLD, 18));
		panel_3.add(label_2);
		
		JPanel panel_4 = new JPanel();
		frame.getContentPane().add(panel_4, BorderLayout.CENTER);
		panel_4.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(new Color(128, 0, 0));
		panel_4.add(panel_5, BorderLayout.NORTH);
		
		JLabel label_4 = new JLabel("Enter CMS ID of Student");
		label_4.setForeground(Color.WHITE);
		label_4.setFont(new Font("Sitka Text", Font.BOLD, 16));
		panel_5.add(label_4);
		
		textField_2 = new JTextField();
		textField_2.setColumns(20);
		panel_5.add(textField_2);
		
		JLabel label_3 = new JLabel("Enter Course code");
		label_3.setForeground(Color.WHITE);
		label_3.setFont(new Font("Sitka Text", Font.BOLD, 16));
		panel_5.add(label_3);
		
		textField_1 = new JTextField();
		textField_1.setColumns(20);
		panel_5.add(textField_1);
		
		JButton button_2 = new JButton("Withdraw it");
		button_2.setForeground(Color.WHITE);
		button_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		button_2.setBackground(Color.BLACK);
		panel_5.add(button_2);
		button_2.addActionListener((e)->
		{
				try
				{
					Connection con = DriverManager.getConnection("jdbc:ucanaccess://AdmissionOffice.accdb");
					String sql = "Select * from Withdraw";
					PreparedStatement ps = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
					ResultSet rs = ps.executeQuery();
					rs.moveToInsertRow();
					rs.updateString("CMS", textField_2.getText());
					rs.updateString("CourseCode", textField_1.getText());
					rs.insertRow();
					JOptionPane.showMessageDialog(null, "Done");
				}
				catch(Exception s)
				{
					JOptionPane.showMessageDialog(null, s);
				}
			
			});
	
		JPanel panel = new JPanel();
		panel.setBackground(new Color(102, 205, 170));
		panel_4.add(panel, BorderLayout.SOUTH);
		
		JButton btnGoToHome = new JButton("Go to Home Page");
		btnGoToHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HomePage h = new HomePage();
				frame.dispose();
			}
		});
		btnGoToHome.setFont(new Font("Sitka Text", Font.BOLD, 17));
		panel.add(btnGoToHome);
	}

}
