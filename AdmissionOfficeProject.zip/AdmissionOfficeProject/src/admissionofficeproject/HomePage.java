package admissionofficeproject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.net.URI;
import java.awt.event.ActionEvent;
import java.awt.Window.Type;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class HomePage {

	private JFrame frame;
	private JTextField rights;
        private ImageIcon imagefahad ;
        private  Image imgf;private Image tempf;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomePage window = new HomePage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public HomePage() {
		initialize();
	}
	public void initialize() {
		frame = new JFrame();
		frame.setBackground(new Color(223, 152, 136));
		frame.setType(Type.POPUP);
		frame.setFont(new Font("Dialog", Font.BOLD, 12));
		frame.getContentPane().setBackground(new Color(255,255,255));
		frame.setBounds(50, 20, 1300, 650);
//		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout(0, 0));
		ImageIcon imageicon = new ImageIcon("adm.jpg");
                frame.setIconImage(imageicon.getImage());
                Image image2 = imageicon.getImage();
                Image temp4 = image2.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                imageicon = new ImageIcon(temp4);
                frame.addWindowListener(new WindowAdapter()
                {
                    @Override
                    public void windowClosing(WindowEvent e) 
                    {
                        int num = JOptionPane.showConfirmDialog(null, "Are you sure do you want to close!", "Closing confirmation", JOptionPane.YES_NO_OPTION);
                        if((num==0))
                        {
                            System.exit(0);
                        }
                        else
                        {
                            new HomePage();
                            frame.dispose();
                        }
                    }
                    
                });
                
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.SOUTH);
		panel.setLayout(new BorderLayout(0, 0));
		
		rights = new JTextField();
		rights.setBackground(new Color(255, 255, 255));
		rights.setHorizontalAlignment(SwingConstants.CENTER);
		rights.setFont(new Font("Tahoma", Font.ITALIC, 12));
		rights.setText("All Rights Reserved");
		panel.add(rights);
		rights.setColumns(10);
		
		ImageIcon image = new ImageIcon("facebook.png");
		Image img = image.getImage();
		Image temp = img.getScaledInstance(60, 40, Image.SCALE_FAST);
		image = new ImageIcon(temp);
		JButton button = new JButton(image);
		button.setBackground(new Color(255, 255, 255));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				try
				{
					Desktop d = Desktop.getDesktop();
					d.browse(new URI("https://www.facebook.com/SukkurIBA.University/"));
				}
				catch(Exception e)
				{
					JOptionPane.showMessageDialog(null, e);
				}
			}
		});
		panel.add(button, BorderLayout.WEST);
		
		image = new ImageIcon("twit.png");
		img = image.getImage();
	    temp = img.getScaledInstance(60, 40, Image.SCALE_FAST);
		image = new ImageIcon(temp);
		JButton button_1 = new JButton(image);
		button_1.setBackground(new Color(255, 255, 255));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					Desktop d = Desktop.getDesktop();
					d.browse(new URI("https://twitter.com/sukkur_iba"));
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, e1);
				}
			}
		});
		panel.add(button_1, BorderLayout.EAST);
		
		image = new ImageIcon("background.png");
		img = image.getImage();
                
		temp = img.getScaledInstance(1400, 800, Image.SCALE_AREA_AVERAGING);
		image = new ImageIcon(temp);
		JLabel label = new JLabel(image);
		frame.getContentPane().add(label);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(new Color(255, 255, 255));
		frame.setJMenuBar(menuBar);
		frame.setVisible(true);
		JMenu mnOptions = new JMenu("Options");
		mnOptions.setFont(new Font("Century Schoolbook", Font.BOLD, 16));
		menuBar.add(mnOptions);
		
		JMenu mnNewEnrollment = new JMenu("New Enrollment");
		mnNewEnrollment.setFont(new Font("Sitka Text", Font.BOLD, 15));
		mnOptions.add(mnNewEnrollment);
		
		JMenuItem mntmFaculty = new JMenuItem("Faculty");
		mntmFaculty.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		mntmFaculty.addActionListener((e)->
		{
			FacultyNew f = new FacultyNew();
			frame.dispose();
		});
		mnNewEnrollment.add(mntmFaculty);
		
		JMenuItem mntmStudent = new JMenuItem("Student");
		mntmStudent.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		mnNewEnrollment.add(mntmStudent);
		mntmStudent.addActionListener((e)->
		{
			NewEnrollment n = new NewEnrollment();
			frame.dispose();
		});
		
		JMenu mnExistingRecord = new JMenu("Existing Record");
		mnExistingRecord.setFont(new Font("Sitka Text", Font.BOLD, 15));
		mnOptions.add(mnExistingRecord);
		
		JMenu mnStudent = new JMenu("Student");
		mnStudent.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		mnExistingRecord.add(mnStudent);
		
		JMenuItem menuItem = new JMenuItem("Search Student");
		menuItem.addActionListener((e)->
		{
			SearchStudent s = new SearchStudent();
			frame.dispose();
		});
		menuItem.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		mnStudent.add(menuItem);
		
	
		JMenu menu = new JMenu("Update Record");
		menu.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		mnStudent.add(menu);
		
		JMenuItem menuItem_1 = new JMenuItem("Withdraw Subject");
		menuItem_1.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		menu.add(menuItem_1);
		menuItem_1.addActionListener((e)->
		{
			WithDraw w = new WithDraw();
			frame.dispose();
		});
		
		JMenuItem menuItem_2 = new JMenuItem("Semester Record");
		menuItem_2.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		menu.add(menuItem_2);
		menuItem_2.addActionListener((e)->
		{
			SemesterDataofStudent s = new SemesterDataofStudent();
			frame.dispose();
		});
		JMenuItem menuItem_3 = new JMenuItem("Remove Record");
		menuItem_3.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		mnStudent.add(menuItem_3);
		menuItem_3.addActionListener((e)->
		{
			DeleteData d = new DeleteData();
			frame.dispose();
		});
		
		JMenuItem menuItem_4 = new JMenuItem("Print Record");
		menuItem_4.setFont(new Font("Sitka Banner", Font.BOLD, 14));
                menuItem_4.addActionListener((e)->
		{
			ShowAll s = new ShowAll();
			frame.dispose();
		});
		mnStudent.add(menuItem_4);
		
		
		JMenu mnFaculty = new JMenu("Faculty");
		mnFaculty.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		mnExistingRecord.add(mnFaculty);
		
		JMenuItem menuItem_6 = new JMenuItem("Search Faculty");
		menuItem_6.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		mnFaculty.add(menuItem_6);
		menuItem_6.addActionListener((e)->
		{
			SearchFaculty s = new SearchFaculty();
			frame.dispose();
		});
		JMenu mnAbout = new JMenu("About");
		mnAbout.setFont(new Font("Century Schoolbook", Font.BOLD, 16));
		menuBar.add(mnAbout);
		
		JMenu mnSoftware = new JMenu("Software");
		mnSoftware.setFont(new Font("Sitka Text", Font.BOLD, 15));
		mnAbout.add(mnSoftware);
		
		JMenuItem mntmShortcuts = new JMenuItem("Shortcuts");
		mntmShortcuts.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		mnSoftware.add(mntmShortcuts);
		
		JMenuItem mntmTools = new JMenuItem("Tools");
		mntmTools.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		mnSoftware.add(mntmTools);
		
		JMenuItem mntmZoomIn = new JMenuItem("Zoom in");
		mntmZoomIn.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		mnSoftware.add(mntmZoomIn);
		
		JMenuItem mntmZoomOut = new JMenuItem("Zoom out");
		mntmZoomOut.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		mnSoftware.add(mntmZoomOut);
		
		JMenu mnDevelopers = new JMenu("Developers");
		mnDevelopers.setFont(new Font("Sitka Text", Font.BOLD, 15));
		mnAbout.add(mnDevelopers);
		
		JMenuItem mntmMFahadShahzad = new JMenuItem("M-Fahad Shahzad");
		mntmMFahadShahzad.addActionListener((ActionEvent e)->
		{
                imagefahad = new ImageIcon("FAHAD.jpg");
                imgf = imagefahad.getImage();
                tempf = imgf.getScaledInstance(150, 200, Image.SCALE_DEFAULT);
                imagefahad = new ImageIcon(tempf);
                    JOptionPane.showMessageDialog(null, "Name : Muhammad Fahad Shahzad nContact : 0301-7021045 \nE-Mail : programmerwarrior9@gmail.com \nAddress : Muzaffargarh , Punjab Pakistan \nCompany : Warrior Group of Companies",  "Information of Engr. Fahad Shahzad", JOptionPane.WARNING_MESSAGE, imagefahad);
		});
		mntmMFahadShahzad.setForeground(new Color(0, 0, 255));
		mntmMFahadShahzad.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		mnDevelopers.add(mntmMFahadShahzad);
		
		JMenuItem mntmMYamin = new JMenuItem("M-Yamin");
		mntmMYamin.addActionListener((e)->
		{
                    imagefahad = new ImageIcon("yamin.jpg");
                    imgf = imagefahad.getImage();
                    tempf = imgf.getScaledInstance(150, 200, Image.SCALE_DEFAULT);
                    imagefahad = new ImageIcon(tempf);
			JOptionPane.showMessageDialog(null, "Name : Muhammad Yamin \nContact : 0307-4748883 \nE-Mail : programmerwarrior9@gmail.com \nAddress : D.G.Khan , Punjab Pakistan \nCompany : Warrior Group of Companies","Information of Engr. Yamin", JOptionPane.WARNING_MESSAGE, imagefahad);
		});
		mntmMYamin.setForeground(new Color(0, 0, 255));
		mntmMYamin.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		mnDevelopers.add(mntmMYamin);
		
		JMenu mnHelp = new JMenu("Help");
		mnHelp.setFont(new Font("Century Schoolbook", Font.BOLD, 16));
		menuBar.add(mnHelp);
		
		JMenu mnDonate = new JMenu("Donate");
		mnDonate.setFont(new Font("Sitka Text", Font.BOLD, 15));
		mnHelp.add(mnDonate);
		
		JMenuItem mntmJazzcash = new JMenuItem("Jazzcash");
		mntmJazzcash.addActionListener((e)->
		{
			JOptionPane.showMessageDialog(null, "0303-0633944");
		});
		mntmJazzcash.setFont(new Font("Sitka Banner", Font.BOLD | Font.ITALIC, 14));
		mntmJazzcash.setForeground(new Color(255, 255, 255));
		mntmJazzcash.setBackground(new Color(255, 0, 0));
		mnDonate.add(mntmJazzcash);
		
		JMenuItem mntmEasypaisa = new JMenuItem("Easypaisa");
		mntmEasypaisa.addActionListener((e)->
		{
			JOptionPane.showMessageDialog(null, "0307-4748883");
		});
		mntmEasypaisa.setFont(new Font("Sitka Banner", Font.BOLD | Font.ITALIC, 14));
		mntmEasypaisa.setForeground(new Color(255, 255, 255));
		mntmEasypaisa.setBackground(new Color(34, 139, 34));
		mnDonate.add(mntmEasypaisa);
		
		JMenuItem mntmBankaccount = new JMenuItem("Bank-Account");
		mntmBankaccount.addActionListener((e)->
		{
			JOptionPane.showMessageDialog(null, "6292 4000 1234 6786");
		});
		mntmBankaccount.setFont(new Font("Sitka Banner", Font.BOLD | Font.ITALIC, 14));
		mntmBankaccount.setForeground(new Color(255, 255, 255));
		mntmBankaccount.setBackground(new Color(255, 140, 0));
		mnDonate.add(mntmBankaccount);
		
		JMenuItem mntmHowToUse = new JMenuItem("How to Use?");
		mntmHowToUse.setFont(new Font("Sitka Text", Font.BOLD, 15));
		mnHelp.add(mntmHowToUse);
		
		JMenuItem mntmFacingProblem = new JMenuItem("Facing Problem?");
		mntmFacingProblem.addActionListener((e)->
		{
			JOptionPane.showMessageDialog(null, "Send any query on the following address\n<html><h2><i><font color=blue><b>admissionofficesibau@gmail.com</font></b></i></h2></html>");
		});
		mntmFacingProblem.setFont(new Font("Sitka Text", Font.BOLD, 15));
		mnHelp.add(mntmFacingProblem);
		
		JMenu mnFaqs = new JMenu("FAQs");
		mnFaqs.setFont(new Font("Century Schoolbook", Font.BOLD, 16));
		menuBar.add(mnFaqs);
		
		JMenuItem mntmFromWhereCan = new JMenuItem("From Where Can I Download it?");
		mntmFromWhereCan.setFont(new Font("Sitka Text", Font.BOLD | Font.ITALIC, 14));
		mntmFromWhereCan.setForeground(new Color(0, 0, 255));
		mnFaqs.add(mntmFromWhereCan);
		
		JMenuItem mntmIsThisFree = new JMenuItem("Is This Free of Cost?");
		mntmIsThisFree.addActionListener((e)->
		{
			JOptionPane.showMessageDialog(null, "Yes! Ofcourse!...");
		});
		mntmIsThisFree.setFont(new Font("Sitka Text", Font.BOLD | Font.ITALIC, 14));
		mntmIsThisFree.setForeground(new Color(0, 0, 255));
		mnFaqs.add(mntmIsThisFree);
		
		JMenuItem mntmICouldntInstall = new JMenuItem("I Could'nt Install it?");
		mntmICouldntInstall.addActionListener((e)->
		{
			JOptionPane.showMessageDialog(null, "Make Enough Space In Your Hard-Disk...");
		});
		mntmICouldntInstall.setFont(new Font("Sitka Text", Font.BOLD | Font.ITALIC, 14));
		mntmICouldntInstall.setForeground(new Color(0, 0, 255));
		mnFaqs.add(mntmICouldntInstall);
		
		JMenuItem mntmIsThisSafe = new JMenuItem("Is This Safe?");
		mntmIsThisSafe.addActionListener((e)->
		{
			JOptionPane.showMessageDialog(null, "We are Well-known about our Safety Techniques...");
		});
		mntmIsThisSafe.setFont(new Font("Sitka Text", Font.BOLD | Font.ITALIC, 14));
		mntmIsThisSafe.setForeground(new Color(0, 0, 255));
		mnFaqs.add(mntmIsThisSafe);
		
		JMenuItem mntmICantAccess = new JMenuItem("I can't Access my Data?");
		mntmICantAccess.addActionListener((e)->
		{
			JOptionPane.showMessageDialog(null, "This is because of following reason\n<html><h3><b><font color=black>You have to install this software without c: drive because file access in c drive in impossible</h3></font></b></html>");
		});
		mntmICantAccess.setForeground(new Color(0, 0, 255));
		mntmICantAccess.setFont(new Font("Sitka Text", Font.BOLD | Font.ITALIC, 15));
		mnFaqs.add(mntmICantAccess);
		
		JMenuItem mntmSecurityIssues = new JMenuItem("Security Issues");
		mntmSecurityIssues.addActionListener((e)->
		{
			JOptionPane.showMessageDialog(null, "We Are Highly Consious In Securing Data Of Our Customer\nBecause Security Is Our First Priority");
		});
		mntmSecurityIssues.setFont(new Font("Sitka Text", Font.BOLD | Font.ITALIC, 14));
		mntmSecurityIssues.setForeground(new Color(0, 0, 255));
		mnFaqs.add(mntmSecurityIssues);
		
		JMenu mnContactUs = new JMenu("Contact Us");
		mnContactUs.setFont(new Font("Century Schoolbook", Font.BOLD, 16));
		menuBar.add(mnContactUs);
		
		JMenuItem mntmMail = new JMenuItem("Mail:");
		mntmMail.addActionListener((e)->
		{
			JOptionPane.showMessageDialog(null, "You May Contact By Following Mail:\n<html><h2><font color=blue>admissionofficesibau@gmail.com</h2></font</html>");
		});
		mntmMail.setForeground(new Color(0, 0, 255));
		mntmMail.setFont(new Font("Sitka Text", Font.BOLD, 15));
		mnContactUs.add(mntmMail);
		
		JMenu mnWhatsapp = new JMenu("Whatsapp");
		mnWhatsapp.setFont(new Font("Sitka Text", Font.BOLD, 15));
		mnContactUs.add(mnWhatsapp);
		
		JMenuItem mntmFahadShahzad = new JMenuItem("Fahad Shahzad");
		mntmFahadShahzad.addActionListener((e)->
		{
			JOptionPane.showMessageDialog(null, "<html><h2><font color=blue>0301-7021045</h2></font></html>");
		});
		mntmFahadShahzad.setForeground(new Color(0, 0, 255));
		mntmFahadShahzad.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		mnWhatsapp.add(mntmFahadShahzad);
		
		JMenuItem mntmYamin = new JMenuItem("Yamin");
		mntmYamin.addActionListener((e)->
		{
			JOptionPane.showMessageDialog(null, "<html><h2><font color=blue>0307-4748883</h2></font></html>");
		});
		mntmYamin.setForeground(new Color(0, 0, 255));
		mntmYamin.setFont(new Font("Sitka Banner", Font.BOLD, 14));
		mnWhatsapp.add(mntmYamin);
		frame.setTitle("Home page of Admission Office");
	}

}
