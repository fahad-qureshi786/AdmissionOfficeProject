package admissionofficeproject;


import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.GridLayout;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class SemesterDataofStudent {

	private JFrame frame;
	private JTextField textField_1;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JComboBox comboBox;
	private JComboBox comboBox_1;
	private JLabel lblEnterGpa;
	private JTextField textField;


	public SemesterDataofStudent() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 610, 337);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(139, 0, 0));
		frame.getContentPane().add(panel, BorderLayout.NORTH);
		
		JLabel lblUpdateSemesterRecord = new JLabel("Update Semester Record Here");
		lblUpdateSemesterRecord.setFont(new Font("Sitka Text", Font.BOLD, 17));
		lblUpdateSemesterRecord.setForeground(new Color(255, 255, 255));
		panel.add(lblUpdateSemesterRecord);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(139, 0, 0));
		frame.getContentPane().add(panel_1, BorderLayout.SOUTH);
		
		JButton btnGoToHome = new JButton("Go to Home");
		btnGoToHome.setForeground(new Color(139, 0, 0));
		btnGoToHome.setFont(new Font("Sitka Text", Font.BOLD, 16));
		panel_1.add(btnGoToHome);
		btnGoToHome.addActionListener((e)->
		{
			HomePage j = new HomePage();
			frame.dispose();
		});
		JButton btnSubmit = new JButton("Submit");
		
		btnSubmit.setForeground(new Color(139, 0, 0));
		btnSubmit.setFont(new Font("Sitka Text", Font.BOLD, 16));
		
		frame.setVisible(true);
		JPanel panel_2 = new JPanel();
		frame.getContentPane().add(panel_2, BorderLayout.CENTER);
		panel_2.setLayout(new GridLayout(0, 2, 8, 8));
		
		JLabel lblNewLabel = new JLabel("CMS : ");
		lblNewLabel.setFont(new Font("Sitka Text", Font.BOLD, 16));
		panel_2.add(lblNewLabel);
		
		JPanel panel_3 = new JPanel();
		panel_2.add(panel_3);
		
		textField_1 = new JTextField();
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_1.setColumns(1);
		panel_3.add(textField_1);
		
		textField_6 = new JTextField();
		textField_6.setHorizontalAlignment(SwingConstants.CENTER);
		textField_6.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_6.setColumns(1);
		panel_3.add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setHorizontalAlignment(SwingConstants.CENTER);
		textField_7.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_7.setColumns(1);
		panel_3.add(textField_7);
		
		textField_8 = new JTextField("-");
		textField_8.setHorizontalAlignment(SwingConstants.CENTER);
		textField_8.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_8.setEditable(false);
		textField_8.setColumns(1);
		panel_3.add(textField_8);
		
		
		textField_9 = new JTextField();
		textField_9.setHorizontalAlignment(SwingConstants.CENTER);
		textField_9.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_9.setColumns(1);
		panel_3.add(textField_9);
		
		textField_10 = new JTextField();
		textField_10.setHorizontalAlignment(SwingConstants.CENTER);
		textField_10.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_10.setColumns(1);
		panel_3.add(textField_10);
		
		textField_11 = new JTextField("-");
		textField_11.setHorizontalAlignment(SwingConstants.CENTER);
		textField_11.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_11.setEditable(false);
		textField_11.setColumns(1);
		panel_3.add(textField_11);
		
		textField_12 = new JTextField();
		textField_12.setHorizontalAlignment(SwingConstants.CENTER);
		textField_12.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_12.setColumns(1);
		panel_3.add(textField_12);
		
		textField_13 = new JTextField();
		textField_13.setHorizontalAlignment(SwingConstants.CENTER);
		textField_13.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_13.setColumns(1);
		panel_3.add(textField_13);
		
		textField_14 = new JTextField();
		textField_14.setHorizontalAlignment(SwingConstants.CENTER);
		textField_14.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_14.setColumns(1);
		panel_3.add(textField_14);
		
		textField_15 = new JTextField();
		textField_15.setHorizontalAlignment(SwingConstants.CENTER);
		textField_15.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_15.setColumns(1);
		panel_3.add(textField_15);
		
		JLabel label = new JLabel("Current Semester #");
		label.setFont(new Font("Sitka Text", Font.BOLD, 16));
		panel_2.add(label);
		
		
		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"I", "II", "III", "IV", "V", "VI", "VII", "VIII"}));
		comboBox.setFont(new Font("Sitka Text", Font.BOLD, 15));
		panel_2.add(comboBox);
		
		JLabel label_3 = new JLabel("Select Department :");
		label_3.setFont(new Font("Sitka Text", Font.BOLD, 16));
		panel_2.add(label_3);
		
		comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"BS-CS", "BEE", "B.ED", "BBA", "BS-AF", "Artifical Intelligence"}));
		comboBox_1.setFont(new Font("Sitka Text", Font.BOLD, 15));
		panel_2.add(comboBox_1);
		
		lblEnterGpa = new JLabel("Enter GPA");
		lblEnterGpa.setFont(new Font("Sitka Text", Font.BOLD, 16));
		panel_2.add(lblEnterGpa);
		
		textField = new JTextField();
		panel_2.add(textField);
		textField.setColumns(10);
		
		JLabel label_2 = new JLabel("");
		panel_2.add(label_2);
		//String cms = ((textField_1.getText())+(textField_6.getText())+(textField_7.getText())+(textField_9.getText())+(textField_10.getText()+(textField_12.getText())+(textField_13.getText())+(textField_14.getText())+(textField_15.getText())));
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0)
			{
				try
				{
					Connection con = DriverManager.getConnection("jdbc:ucanaccess://AdmissionOffice.accdb");
					String sql = "Select * from SemesterStudent";
					PreparedStatement ps = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
					ResultSet rs = ps.executeQuery();
					rs.moveToInsertRow();
					rs.updateString("CMS", ((textField_1.getText())+(textField_6.getText())+(textField_7.getText())+(textField_9.getText())+(textField_10.getText()+(textField_12.getText())+(textField_13.getText())+(textField_14.getText())+(textField_15.getText()))));
					rs.updateString("SemesterNumber", comboBox.getSelectedItem()+"");
					rs.updateString("Department", comboBox_1.getSelectedItem()+"");
					rs.updateString("GPA", textField.getText());
					JOptionPane.showMessageDialog(null, "Thanks..");
					rs.insertRow();
					con.close();
					ps.close();
				}
				catch(Exception e)
				{
					JOptionPane.showMessageDialog(null, e);
				}
			}
		});
		
		
		panel_1.add(btnSubmit);
	}

}
