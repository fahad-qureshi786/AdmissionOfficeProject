    package admissionofficeproject;


    import javax.swing.JFrame;
    import java.awt.BorderLayout;
    import javax.swing.JPanel;
    import javax.swing.JLabel;
    import javax.swing.JOptionPane;

    import java.awt.Font;
    import java.awt.Color;
    import javax.swing.JButton;
    import javax.swing.border.BevelBorder;
    import java.awt.event.ActionListener;
    import java.sql.Connection;
    import java.sql.DriverManager;
    import java.sql.PreparedStatement;
    import java.sql.ResultSet;
    import java.awt.event.ActionEvent;
    import javax.swing.JTextField;
    import javax.swing.SwingConstants;

    public class DeleteData {

            private JFrame frame;
            private JTextField textField;


            public DeleteData() {
                    initialize();
            }

            private void initialize() {
                    frame = new JFrame();
                    frame.setBounds(100, 100, 900, 600);
                    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    frame.getContentPane().setLayout(new BorderLayout(0, 0));
                    frame.setVisible(true);
                    JPanel panel = new JPanel();
                    panel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
                    panel.setBackground(new Color(240, 230, 140));
                    frame.getContentPane().add(panel, BorderLayout.NORTH);

                    JLabel lblDeleteDataThat = new JLabel("Delete data that you had entered");
                    lblDeleteDataThat.setFont(new Font("Tahoma", Font.BOLD, 16));
                    panel.add(lblDeleteDataThat);

                    JPanel panel_1 = new JPanel();
                    panel_1.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
                    panel_1.setBackground(new Color(240, 230, 140));
                    frame.getContentPane().add(panel_1, BorderLayout.SOUTH);

                    JButton homebtn = new JButton("Go to Home Page");
                    homebtn.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent arg0) {
                            }
                    });
                    homebtn.setForeground(new Color(165, 42, 42));
                    homebtn.setFont(new Font("Tahoma", Font.BOLD, 15));
                    homebtn.setToolTipText("Click me for going to home Page");
                    homebtn.addActionListener((E)->
                    {
                            HomePage home = new HomePage();
                            frame.dispose();
                    });

                    panel_1.add(homebtn);

                    JPanel panel_2 = new JPanel();
                    frame.getContentPane().add(panel_2, BorderLayout.CENTER);
                    panel_2.setLayout(new BorderLayout(0, 0));

                    JPanel panel_3 = new JPanel();
                    panel_3.setBackground(new Color(216, 191, 216));
                    panel_2.add(panel_3, BorderLayout.NORTH);

                    JLabel lblEnterTheName = new JLabel("Enter the CMS of Student For Removing the data");
                    lblEnterTheName.setFont(new Font("Tahoma", Font.BOLD, 16));
                    panel_3.add(lblEnterTheName);
                    frame.setTitle("delete page of Student Admission System");
                    textField = new JTextField();
                    textField.setFont(new Font("Tahoma", Font.BOLD, 16));
                    panel_3.add(textField);
                    textField.setColumns(20);

                    JButton btnOkDeleteIt = new JButton("Ok delete it");
                    btnOkDeleteIt.setForeground(new Color(255, 255, 255));
                    btnOkDeleteIt.setBackground(new Color(0, 0, 0));
                    btnOkDeleteIt.setFont(new Font("Tahoma", Font.BOLD, 16));
                    panel_3.add(btnOkDeleteIt);
                    btnOkDeleteIt.addActionListener((e)->
                    {
                            try
                            {
                                    Connection con = DriverManager.getConnection("jdbc:ucanaccess://AdmissionOffice.accdb");
                                    String sql = "Select * from StudentPermanant";
                                    PreparedStatement ps = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                                    ResultSet rs = ps.executeQuery();
                                    boolean flag = false;
                                    while(rs.next())
                                    {
                                            if(rs.getString("CMS").equals(textField.getText()))
                                            {
                                                    rs.updateBoolean("Delete", true);
                                                    flag=true;
                                                    JOptionPane.showMessageDialog(null, "Deleted Successfully..");
                                                    break;
                                            }
                                    }
                                    if(flag==false)
                                    {
                                        JOptionPane.showMessageDialog(null, "Student doesn't exist of this cms");
                                    }
                                    rs.updateRow();
                                    con.close();
                                    ps.close();
                            }
                            catch(Exception y)
                            {
                                    JOptionPane.showMessageDialog(null, y);
                            }
                    });

                    JLabel lblResponseWillBe = new JLabel("Response will be appear here");
                    lblResponseWillBe.setFont(new Font("Tahoma", Font.BOLD, 15));
                    lblResponseWillBe.setHorizontalAlignment(SwingConstants.CENTER);
                    panel_2.add(lblResponseWillBe, BorderLayout.CENTER);
            }

    }
