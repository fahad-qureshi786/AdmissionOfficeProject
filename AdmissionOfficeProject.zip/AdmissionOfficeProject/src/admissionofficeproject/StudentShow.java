package admissionofficeproject;

public class StudentShow 
{
	private String name,cms,fatherName,cnic,gender,department,address,province,contactStudent,contactFather,joiningDate;
	
    public StudentShow(String name, String cms, String fatherName, String cnic, String gender, String department, String address, String province, String contactStudent, String contactFather, String joiningDate) {
        this.name = name;
        this.cms = cms;
        this.fatherName = fatherName;
        this.cnic = cnic;
        this.gender = gender;
        this.department = department;
        this.address = address;
        this.province = province;
        this.contactStudent = contactStudent;
        this.contactFather = contactFather;
        this.joiningDate = joiningDate;
        
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCms() {
        return cms;
    }

    public void setCms(String cms) {
        this.cms = cms;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getCnic() {
        return cnic;
    }

    public void setCnic(String cnic) {
        this.cnic = cnic;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getContactStudent() {
        return contactStudent;
    }

    public void setContactStudent(String contactStudent) {
        this.contactStudent = contactStudent;
    }

    public String getContactFather() {
        return contactFather;
    }

    public void setContactFather(String contactFather) {
        this.contactFather = contactFather;
    }

    public String getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(String joiningDate) {
        this.joiningDate = joiningDate;
    }

    @Override
    public String toString() {
        return "StudentShow{" + "name=" + name + ", cms=" + cms + ", fatherName=" + fatherName + ", cnic=" + cnic + ", gender=" + gender + ", department=" + department + ", address=" + address + ", province=" + province + ", contactStudent=" + contactStudent + ", contactFather=" + contactFather + ", joiningDate=" + joiningDate + '}';
    }
    
}
