package admissionofficeproject;


import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JTextField;

public class SearchFaculty {

	private JFrame frame;
	private JTextField textField;
	private String name,cms,fatherName,cnic,gender,department,address,qualification,contact,email,joiningDate;


	public SearchFaculty() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 647, 365);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(60, 179, 113));
		frame.getContentPane().add(panel, BorderLayout.NORTH);
		frame.setVisible(true);
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(60, 179, 113));
		panel.add(panel_1);
		
		JLabel label = new JLabel("Search Any Data That you have Entered");
		label.setFont(new Font("Sitka Text", Font.BOLD, 18));
		panel_1.add(label);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(60, 179, 113));
		frame.getContentPane().add(panel_2, BorderLayout.SOUTH);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(60, 179, 113));
		panel_2.add(panel_3);
		
		JButton button = new JButton("Go to Home");
		button.setFont(new Font("Sitka Text", Font.BOLD, 18));
		panel_3.add(button);
		button.addActionListener((e)->
		{
			HomePage h = new HomePage();
			frame.dispose();
		});
		JPanel panel_4 = new JPanel();
		frame.getContentPane().add(panel_4, BorderLayout.CENTER);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(new Color(128, 0, 0));
		panel_4.add(panel_5);
		
		JLabel label_1 = new JLabel("Enter CMS ID");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("Sitka Text", Font.BOLD, 16));
		panel_5.add(label_1);
		
		textField = new JTextField();
		textField.setColumns(20);
		panel_5.add(textField);
		
		JButton button_1 = new JButton("Search it");
		button_1.setForeground(Color.WHITE);
		button_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		button_1.setBackground(Color.BLACK);
		
		button_1.addActionListener((e)->
		{
			try
			{
				Connection con = DriverManager.getConnection("jdbc:ucanaccess://AdmissionOffice.accdb");
				String sql = "Select * from Faculty ";
				PreparedStatement ps = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
				ResultSet rs = ps.executeQuery();
				while(rs.next())
				{
					if(rs.getString("CMS").equals(textField.getText()))
					{
						
						cms = rs.getString("CMS");

						name = rs.getString("Name");
						fatherName =rs.getString("FatherName");
						cnic = rs.getString("CNIC");
						gender = rs.getString("Gender");
						address = rs.getString("Address");
						department = rs.getString("Department");
						email = rs.getString("E-Mail");
						contact = rs.getString("Contact");
						qualification = rs.getString("Qualification");
						joiningDate = rs.getString("DateJoining");
						JOptionPane.showMessageDialog(null, "CMS of Faculty:    "+ cms+"\nName of Faculty:    "+ name+"\nFather Name of Faculty:    "+ fatherName+"\nGender of Faculty:    "+ gender+"\nAddress of Faculty:    "+ address+"\nDepartment of Faculty:    "+ department+"\nQualification of Student:    "+ qualification+"\nContact number of Faculty:    "+ contact+"\nEmail-ID of Faculty:    "+email +"\nJoining date of Student:    "+ joiningDate);
						
						break;
					}
				
				}
				
			}
			catch(Exception s)
			{
				JOptionPane.showMessageDialog(null, s);
			}
		
		});
		
		panel_5.add(button_1);
	}

}
