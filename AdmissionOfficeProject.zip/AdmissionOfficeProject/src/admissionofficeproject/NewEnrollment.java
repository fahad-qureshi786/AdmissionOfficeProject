package admissionofficeproject;


import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.ButtonGroup;

import java.awt.GridLayout;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.SwingConstants;

public class NewEnrollment {

	private JFrame frame;
	private JTextField textField_1;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField;
	private JTextField textField_2;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_17;

	public NewEnrollment() {
		initialize();
	}
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Add new student data ");
		frame.setBounds(100, 20, 900, 700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(139, 0, 0));
		frame.getContentPane().add(panel, BorderLayout.SOUTH);
		panel.setLayout(new BorderLayout(0, 0));
		
		JButton button = new JButton("<---- Go to Home");
		button.setFont(new Font("Sitka Banner", Font.BOLD, 16));
		button.setBackground(new Color(255, 255, 255));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HomePage home = new HomePage();
				frame.dispose();
			}
		});
		panel.add(button, BorderLayout.WEST);
		
		
		JPanel panel_1 = new JPanel();
		frame.getContentPane().add(panel_1, BorderLayout.NORTH);
		panel_1.setLayout(new GridLayout(0, 2,12,12));
		frame.setVisible(true);
		JLabel lblEnterStudentName = new JLabel("Enter Student Name");
		lblEnterStudentName.setBackground(new Color(135, 206, 250));
		lblEnterStudentName.setHorizontalAlignment(SwingConstants.LEFT);
		lblEnterStudentName.setFont(new Font("Sitka Small", Font.BOLD, 18));
		panel_1.add(lblEnterStudentName);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Sitka Banner", Font.BOLD, 15));
		panel_1.add(textField_1);
		textField_1.setColumns(20);
		
		JLabel lblNewLabel_1 = new JLabel("Enter Father Name of Student");
		lblNewLabel_1.setBackground(new Color(135, 206, 250));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setFont(new Font("Sitka Small", Font.BOLD, 18));
		panel_1.add(lblNewLabel_1);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Sitka Banner", Font.BOLD, 15));
		panel_1.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Enter CNIC of Student");
		lblNewLabel.setBackground(new Color(135, 206, 250));
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setFont(new Font("Sitka Small", Font.BOLD, 18));
		panel_1.add(lblNewLabel);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Sitka Banner", Font.BOLD, 15));
		panel_1.add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Enter Province of Student");
		lblNewLabel_3.setBackground(new Color(135, 206, 250));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_3.setFont(new Font("Sitka Small", Font.BOLD, 18));
		panel_1.add(lblNewLabel_3);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Sitka Banner", Font.BOLD, 15));
		panel_1.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Enter Contact Number of Student");
		lblNewLabel_4.setBackground(new Color(135, 206, 250));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_4.setFont(new Font("Sitka Small", Font.BOLD, 18));
		panel_1.add(lblNewLabel_4);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Sitka Banner", Font.BOLD, 15));
		panel_1.add(textField_6);
		textField_6.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Enter Father's Contact Number");
		lblNewLabel_5.setBackground(new Color(135, 206, 250));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_5.setFont(new Font("Sitka Small", Font.BOLD, 18));
		panel_1.add(lblNewLabel_5);
		
		textField_7 = new JTextField();
		textField_7.setFont(new Font("Sitka Banner", Font.BOLD, 15));
		panel_1.add(textField_7);
		textField_7.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Enter Home Address of Student");
		lblNewLabel_2.setBackground(new Color(135, 206, 250));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_2.setFont(new Font("Sitka Small", Font.BOLD, 18));
		panel_1.add(lblNewLabel_2);
		
		textField_8 = new JTextField();
		textField_8.setFont(new Font("Sitka Banner", Font.BOLD, 15));
		panel_1.add(textField_8);
		textField_8.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Select Gender of Student");
		lblNewLabel_6.setBackground(new Color(135, 206, 250));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6.setFont(new Font("Sitka Small", Font.BOLD, 18));
		panel_1.add(lblNewLabel_6);
		
		JPanel panel_2 = new JPanel();
		panel_1.add(panel_2);
		
		ButtonGroup bg = new ButtonGroup();
		JRadioButton rdbtnMale = new JRadioButton("Male");
		panel_2.add(rdbtnMale);
		
		JRadioButton rdbtnFemale = new JRadioButton("Female");
		panel_2.add(rdbtnFemale);
		bg.add(rdbtnFemale);
		bg.add(rdbtnMale);
		
		JLabel lblNewLabel_7 = new JLabel("Select Department for Student");
		lblNewLabel_7.setBackground(new Color(135, 206, 250));
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_7.setFont(new Font("Sitka Small", Font.BOLD, 18));
		panel_1.add(lblNewLabel_7);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"", "Computer Science", "BBA", "Software Engineering", "Artificial Intelligence", "Electrical Engineering", "B-ed", "BS-Accounting & Finance", "BS-Mathematics"}));
		panel_1.add(comboBox);
		
		JLabel lblSelectDateOf = new JLabel("Select Date of Joining");
		lblSelectDateOf.setBackground(new Color(135, 206, 250));
		lblSelectDateOf.setHorizontalAlignment(SwingConstants.LEFT);
		lblSelectDateOf.setFont(new Font("Sitka Banner", Font.BOLD, 19));
		panel_1.add(lblSelectDateOf);
		
		JPanel panel_3 = new JPanel();
		panel_1.add(panel_3);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		panel_3.add(comboBox_1);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}));
		panel_3.add(comboBox_2);
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setMaximumRowCount(40);
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032"}));
		panel_3.add(comboBox_3);
		
		JLabel label = new JLabel("Enter Issued CMS ID");
		label.setBackground(new Color(135, 206, 250));
		label.setHorizontalAlignment(SwingConstants.LEFT);
		label.setFont(new Font("Sitka Banner", Font.BOLD, 19));
		panel_1.add(label);
		
		JPanel panel_4 = new JPanel();
		panel_1.add(panel_4);
		
		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		panel_4.add(textField);
		textField.setColumns(1);
		
		textField_2 = new JTextField();
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		panel_4.add(textField_2);
		textField_2.setColumns(1);
		
		textField_17 = new JTextField();
		textField_17.setHorizontalAlignment(SwingConstants.CENTER);
		textField_17.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_17.setColumns(1);
		panel_4.add(textField_17);
		
		textField_9 = new JTextField("-");
		textField_9.setHorizontalAlignment(SwingConstants.CENTER);
		textField_9.setEditable(false);
		textField_9.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_9.setColumns(1);
		panel_4.add(textField_9);
		
		textField_10 = new JTextField();
		textField_10.setHorizontalAlignment(SwingConstants.CENTER);
		textField_10.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_10.setColumns(1);
		panel_4.add(textField_10);
		
		textField_11 = new JTextField();
		textField_11.setHorizontalAlignment(SwingConstants.CENTER);
		textField_11.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_11.setColumns(1);
		panel_4.add(textField_11);
		
		textField_12 = new JTextField("-");
		textField_12.setEditable(false);
		textField_12.setHorizontalAlignment(SwingConstants.CENTER);
		textField_12.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_12.setColumns(1);
		panel_4.add(textField_12);
		
		textField_13 = new JTextField();
		textField_13.setHorizontalAlignment(SwingConstants.CENTER);
		textField_13.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_13.setColumns(1);
		panel_4.add(textField_13);
		
		textField_14 = new JTextField();
		textField_14.setHorizontalAlignment(SwingConstants.CENTER);
		textField_14.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_14.setColumns(1);
		panel_4.add(textField_14);
		
		textField_15 = new JTextField();
		textField_15.setHorizontalAlignment(SwingConstants.CENTER);
		textField_15.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_15.setColumns(1);
		panel_4.add(textField_15);
		
		textField_16 = new JTextField();
		textField_16.setHorizontalAlignment(SwingConstants.CENTER);
		textField_16.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_16.setColumns(1);
		panel_4.add(textField_16);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setFont(new Font("Sitka Banner", Font.BOLD, 16));
		btnSubmit.setBackground(new Color(255, 255, 255));
		panel.add(btnSubmit, BorderLayout.EAST);
		btnSubmit.addActionListener((e)->
		{
			try
			{
				Connection con = DriverManager.getConnection("jdbc:ucanaccess://AdmissionOffice.accdb");
				String sql = "Select * from StudentPermanant";
                                String sql2 = "Select * from SemesterStudent";
				PreparedStatement ps = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
				PreparedStatement ps2 = con.prepareStatement(sql2, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
				ResultSet rs = ps.executeQuery();
                                ResultSet rs2 = ps2.executeQuery();
                                rs.moveToInsertRow();
                                rs2.moveToInsertRow();
				rs.updateString("CMS", ((textField.getText())+(textField_2.getText())+(textField_17.getText())+"-"+(textField_10.getText())+(textField_11.getText()+"-"+(textField_13.getText())+(textField_14.getText())+(textField_15.getText())+(textField_16.getText()))));
				rs.updateString("Name",textField_1.getText() );
				rs.updateString("Department", comboBox_1.getSelectedItem()+"");
				rs.updateString("Name",textField_1.getText() );
				rs.updateString("FatherName",textField_3.getText() );
				rs.updateString("CNIC",textField_4.getText() );
				rs.updateString("Address",textField_8.getText() );
				rs.updateString("Province",textField_5.getText() );
                                rs2.updateString("CMS", ((textField.getText())+(textField_2.getText())+(textField_17.getText())+"-"+(textField_10.getText())+(textField_11.getText()+"-"+(textField_13.getText())+(textField_14.getText())+(textField_15.getText())+(textField_16.getText()))));
				rs.updateString("ContactStudent",textField_6.getText() );
				rs.updateString("ContactFather",textField_7.getText() );
				rs.updateString("DateOfJoining",comboBox_1.getSelectedItem()+"/"+comboBox_2.getSelectedItem()+"/"+comboBox_3.getSelectedItem());
				String gen;
				if(rdbtnMale.isSelected())
				{
					gen="male";
				}
				else
				{
					gen="female";
				}
				rs.updateString("Gender",gen);
				rs.updateString("Department",comboBox.getSelectedItem()+"");
				JOptionPane.showMessageDialog(null, "Thanks..");
				rs.insertRow();
                                rs2.insertRow();
				con.close();
				ps.close();
				HomePage h = new HomePage();
				frame.dispose();
			}
			catch(Exception d)
			{
				JOptionPane.showMessageDialog(null, d);
			}
		});
		JPanel panel_5 = new JPanel();
		panel_1.add(panel_5);
		
	}

}
