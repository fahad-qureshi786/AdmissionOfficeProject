package admissionofficeproject;


import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JTextField;
import java.awt.GridLayout;


public class SearchStudent {

	private JFrame frame;
	private JTextField textField;
	private String name,cms,fatherName,cnic,gender,department,address,province,contactStudent,contactFather,joiningDate;
	public SearchStudent() {
		initialize();
	}
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Search Student data");
		frame.setBounds(100, 100, 900, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(102, 205, 170));
		frame.getContentPane().add(panel, BorderLayout.NORTH);
		
		JLabel lblSearchAnyData = new JLabel("Search Any Data That you have Entered");
		lblSearchAnyData.setFont(new Font("Sitka Text", Font.BOLD, 18));
		panel.add(lblSearchAnyData);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(60, 179, 113));
		frame.getContentPane().add(panel_1, BorderLayout.SOUTH);
		
		JButton btnGoToHome = new JButton("Go to Home");
		btnGoToHome.addActionListener((e)->
		{
			
					HomePage home = new HomePage();
					frame.dispose();
			
		});
		btnGoToHome.setFont(new Font("Sitka Text", Font.BOLD, 18));
		panel_1.add(btnGoToHome);
		
		JPanel panel_2 = new JPanel();
		frame.getContentPane().add(panel_2, BorderLayout.CENTER);
		panel_2.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(128, 0, 0));
		panel_2.add(panel_3, BorderLayout.NORTH);
		
		JLabel lblEnterStudentCms = new JLabel("Enter CMS ID");
		lblEnterStudentCms.setForeground(new Color(255, 255, 255));
		lblEnterStudentCms.setFont(new Font("Sitka Text", Font.BOLD, 16));
		panel_3.add(lblEnterStudentCms);
		
		textField = new JTextField();
		panel_3.add(textField);
		textField.setColumns(20);
		
		JButton button = new JButton("Search it");
		button.setForeground(Color.WHITE);
		button.setFont(new Font("Tahoma", Font.BOLD, 14));
		button.setBackground(Color.BLACK);
		panel_3.add(button);
		
		JPanel panel_4 = new JPanel();
		
		panel_4.setLayout(new GridLayout(0, 12, 12, 12));
		
		button.addActionListener((e)->
		{
			try
			{
				Connection con = DriverManager.getConnection("jdbc:ucanaccess://AdmissionOffice.accdb");
				String sql = "Select * from StudentPermanant where Delete=no";
				PreparedStatement ps = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
				ResultSet rs = ps.executeQuery();
				while(rs.next())
				{
					if(rs.getString("CMS").equals(textField.getText()))
					{
						
						cms = rs.getString("CMS");

						name = rs.getString("Name");
						fatherName =rs.getString("FatherName");
						cnic = rs.getString("CNIC");
						gender = rs.getString("Gender");
						address = rs.getString("Address");
						department = rs.getString("Department");
						province = rs.getString("Province");
						contactStudent = rs.getString("ContactStudent");
						contactFather = rs.getString("ContactFather");
						joiningDate = rs.getString("DateOfJoining");
						JOptionPane.showMessageDialog(null, "CMS of Student:    "+ cms+"\nName of Student:    "+ name+"\nFather Name of Student:    "+ fatherName+"\nGender of Student:    "+ gender+"\nAddress of Student:    "+ address+"\nDepartment of Student:    "+ department+"\nProvince of Student:    "+ province+"\nContact number of Student:    "+ contactStudent+"\nContact number father of Student:    "+ contactFather+"\nJoining date of Student:    "+ joiningDate);
						
						break;
					}
				
				}
				
			}
			catch(Exception s)
			{
				JOptionPane.showMessageDialog(null, s);
			}
		
		});
		panel_2.add(panel_4, BorderLayout.CENTER);
	}

}
