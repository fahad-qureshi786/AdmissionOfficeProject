package admissionofficeproject;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class ShowAll 
{
    private JFrame frame;
         
	
	public ShowAll() {
		initialize();
	}
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 860, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout(0, 0));
		frame.setVisible(true);
		frame.setTitle("over all data page of Books management System");
		JPanel panel = new JPanel();
		panel.setBackground(new Color(240, 230, 140));
		frame.getContentPane().add(panel, BorderLayout.NORTH);
		
		JLabel lblThisIsComplete = new JLabel("THIS IS COMPLETE DATA OF BOOKS");
		lblThisIsComplete.setFont(new Font("MS PGothic", Font.BOLD, 23));
                JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(240, 230, 140));
		frame.getContentPane().add(panel_1, BorderLayout.SOUTH);
		
		JButton btnGoToHome = new JButton("Go to Home Page");
		btnGoToHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				HomePage home = new HomePage();
				frame.dispose();
			}
		});
		btnGoToHome.setFont(new Font("Gadugi", Font.BOLD, 16));
		btnGoToHome.setForeground(new Color(0, 0, 128));
		panel_1.add(btnGoToHome);
		panel.add(lblThisIsComplete);
		          try {
                    
                        Connection con = DriverManager.getConnection("jdbc:ucanaccess://AdmissionOffice.accdb");
                        String sql = "select * from StudentPermanant where Delete=no";
                        PreparedStatement ps = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                        ResultSet rs = ps.executeQuery();
                        ArrayList ar = new ArrayList();
                        boolean flag=false;
                        String cms,name, fatherName,cnic,address,province,contactStd,contactFat,gen,department,date;
                        while(rs.next())
                        {
                               cms = rs.getString("CMS");
                               name = rs.getString("Name");
                               fatherName = rs.getString("FatherName");
                               cnic = rs.getString("CNIC");
                               address = rs.getString("Address");
                               province = rs.getString("Province");
                               contactStd = rs.getString("ContactStudent");
                               contactFat = rs.getString("ContactFather");
                               gen = rs.getString("Gender");
                               department = rs.getString("Department");
                               date = rs.getString("DateOfJoining");
                               StudentShow student = new StudentShow(name, cms, fatherName, cnic, gen, department, address, province, contactStd, contactFat, date);
                               ar.add(student+"\n");
                               flag=true;
                        }
                        JOptionPane.showMessageDialog(null, ar);
                        if(flag==false)
                        {
                            JOptionPane.showMessageDialog(null, "No data is exist");
                        }
                        ps.close();
                        con.close();
                        }
                        catch(SQLException s)
                        {
                            JOptionPane.showMessageDialog(null, s);
                        }
	}

    
}
