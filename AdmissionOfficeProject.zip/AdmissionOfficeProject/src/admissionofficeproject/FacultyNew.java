package admissionofficeproject;


import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.GridLayout;
import java.awt.Image;
import javax.swing.border.BevelBorder;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JRadioButton;

public class FacultyNew {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_1;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_17;
	private JTextField textField_18;

	public FacultyNew() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1000, 700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout(0, 0));
		frame.setTitle("Welcome for new faculty");
		JPanel panel = new JPanel();
		panel.setBackground(new Color(165, 42, 42));
		frame.getContentPane().add(panel, BorderLayout.NORTH);
		ImageIcon image = new ImageIcon("student.png");
                Image img = image.getImage();
                Image temp = img.getScaledInstance(80, 80, Image.SCALE_DEFAULT);
                image = new ImageIcon(temp);
		JLabel lblWelcomeForNew = new JLabel("Welcome For New Faculty Data In Institute");
                lblWelcomeForNew.setIcon(image);
		lblWelcomeForNew.setFont(new Font("Sitka Text", Font.BOLD, 18));
		lblWelcomeForNew.setForeground(new Color(255, 255, 255));
		panel.add(lblWelcomeForNew);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(165, 42, 42));
		frame.getContentPane().add(panel_1, BorderLayout.SOUTH);
		
		JButton btnGoToHome = new JButton("Go to Home Page");
		btnGoToHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HomePage home = new HomePage();
				frame.dispose();
			}
		});
		btnGoToHome.setFont(new Font("Sitka Banner", Font.BOLD, 16));
		panel_1.add(btnGoToHome);
		
		JButton btnSubmit = new JButton("Submit");
		
		
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		frame.getContentPane().add(panel_2, BorderLayout.CENTER);
		panel_2.setLayout(new GridLayout(0, 2,20,20));
		frame.setVisible(true);
		JLabel lblNewLabel = new JLabel("Enter Name Of New Faculty    ");
		lblNewLabel.setFont(new Font("Sitka Text", Font.BOLD, 16));
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		panel_2.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setColumns(10);
		panel_2.add(textField);
		
		JLabel label = new JLabel("Enter Father Name      ");
		label.setFont(new Font("Sitka Text", Font.BOLD, 16));
		label.setHorizontalAlignment(SwingConstants.LEFT);
		panel_2.add(label);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		panel_2.add(textField_2);
		
		JLabel label_1 = new JLabel("Enter CNIC of Faculty   ");
		label_1.setFont(new Font("Sitka Text", Font.BOLD, 16));
		label_1.setHorizontalAlignment(SwingConstants.LEFT);
		panel_2.add(label_1);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		panel_2.add(textField_3);
		
		JLabel label_2 = new JLabel("Enter Qualification    ");
		label_2.setFont(new Font("Sitka Text", Font.BOLD, 16));
		label_2.setHorizontalAlignment(SwingConstants.LEFT);
		panel_2.add(label_2);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		panel_2.add(textField_4);
		
		JLabel label_3 = new JLabel("Enter Address Of Faculty");
		label_3.setFont(new Font("Sitka Text", Font.BOLD, 16));
		label_3.setHorizontalAlignment(SwingConstants.LEFT);
		panel_2.add(label_3);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		panel_2.add(textField_5);
		
		JLabel label_4 = new JLabel("Select Department for Hire");
		label_4.setFont(new Font("Sitka Text", Font.BOLD, 16));
		label_4.setHorizontalAlignment(SwingConstants.LEFT);
		panel_2.add(label_4);
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"CS", "EE", "A & F", "B-Ed", "BBA", "Artificial Intelligence"}));
		comboBox_3.setMaximumRowCount(40);
		panel_2.add(comboBox_3);
		
		JLabel label_5 = new JLabel("Enter Contact Number");
		label_5.setFont(new Font("Sitka Text", Font.BOLD, 16));
		label_5.setHorizontalAlignment(SwingConstants.LEFT);
		panel_2.add(label_5);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		panel_2.add(textField_7);
		
		JLabel label_6 = new JLabel("Enter Mail:  ");
		label_6.setFont(new Font("Sitka Text", Font.BOLD, 16));
		label_6.setHorizontalAlignment(SwingConstants.LEFT);
		panel_2.add(label_6);
		
		textField_8 = new JTextField();
		textField_8.setColumns(10);
		panel_2.add(textField_8);
		
		JLabel label_7 = new JLabel("Select Date Of Joining    ");
		label_7.setFont(new Font("Sitka Text", Font.BOLD, 16));
		label_7.setHorizontalAlignment(SwingConstants.LEFT);
		panel_2.add(label_7);
		
		JPanel panel_4 = new JPanel();
		panel_2.add(panel_4);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		panel_4.add(comboBox);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}));
		panel_4.add(comboBox_1);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032"}));
		comboBox_2.setMaximumRowCount(40);
		panel_4.add(comboBox_2);
		
		JLabel label_8 = new JLabel("Enter CMS for Faculty   ");
		label_8.setFont(new Font("Sitka Text", Font.BOLD, 16));
		label_8.setHorizontalAlignment(SwingConstants.LEFT);
		panel_2.add(label_8);
		
		JPanel panel_3 = new JPanel();
		panel_2.add(panel_3);
		
		textField_1 = new JTextField();
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_1.setColumns(1);
		panel_3.add(textField_1);
		
		textField_9 = new JTextField();
		textField_9.setHorizontalAlignment(SwingConstants.CENTER);
		textField_9.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_9.setColumns(1);
		panel_3.add(textField_9);
		
		textField_10 = new JTextField();
		textField_10.setHorizontalAlignment(SwingConstants.CENTER);
		textField_10.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_10.setColumns(1);
		panel_3.add(textField_10);
		
		textField_11 = new JTextField("-");
		textField_11.setHorizontalAlignment(SwingConstants.CENTER);
		textField_11.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_11.setEditable(false);
		textField_11.setColumns(1);
		panel_3.add(textField_11);
		
		textField_12 = new JTextField();
		textField_12.setHorizontalAlignment(SwingConstants.CENTER);
		textField_12.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_12.setColumns(1);
		panel_3.add(textField_12);
		
		textField_13 = new JTextField();
		textField_13.setHorizontalAlignment(SwingConstants.CENTER);
		textField_13.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_13.setColumns(1);
		panel_3.add(textField_13);
		
		textField_14 = new JTextField("-");
		textField_14.setHorizontalAlignment(SwingConstants.CENTER);
		textField_14.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_14.setEditable(false);
		textField_14.setColumns(1);
		panel_3.add(textField_14);
		
		textField_15 = new JTextField();
		textField_15.setHorizontalAlignment(SwingConstants.CENTER);
		textField_15.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_15.setColumns(1);
		panel_3.add(textField_15);
		
		textField_16 = new JTextField();
		textField_16.setHorizontalAlignment(SwingConstants.CENTER);
		textField_16.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_16.setColumns(1);
		panel_3.add(textField_16);
		
		textField_17 = new JTextField();
		textField_17.setHorizontalAlignment(SwingConstants.CENTER);
		textField_17.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_17.setColumns(1);
		panel_3.add(textField_17);
		
		textField_18 = new JTextField();
		textField_18.setHorizontalAlignment(SwingConstants.CENTER);
		textField_18.setFont(new Font("Sitka Banner", Font.BOLD, 18));
		textField_18.setColumns(1);
		panel_3.add(textField_18);
		
		JLabel label_9 = new JLabel("Select Gender   ");
		label_9.setHorizontalAlignment(SwingConstants.LEFT);
		label_9.setFont(new Font("Sitka Text", Font.BOLD, 16));
		panel_2.add(label_9);
		/*
                if((textField.equals(null)||textField_1.equals(null)||textField_2.equals(null)||textField_3.equals(null)||textField_4.equals(null)||textField_5.equals(null)||textField_7.equals(null)||textField_8.equals(null)||textField_8.equals(null)||textField_10.equals(null)||textField_11.equals(null)||textField_12.equals(null)||textField_13.equals(null)||textField_14.equals(null)||textField_15.equals(null)||textField_16.equals(null)||textField_17.equals(null)||textField_18.equals(null)))
                {
                   btnSubmit.setEnabled(false);
                   
                }
                */
		JPanel panel_5 = new JPanel();
		panel_2.add(panel_5);
		ButtonGroup bg = new ButtonGroup();
		JRadioButton radioButton = new JRadioButton("Male");
		panel_5.add(radioButton);
		bg.add(radioButton);
		JRadioButton radioButton_1 = new JRadioButton("Female");
		panel_5.add(radioButton_1);
		bg.add(radioButton_1);
		btnSubmit.setFont(new Font("Sitka Banner", Font.BOLD, 16));
		panel_1.add(btnSubmit);
    
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
                 
					Connection con = DriverManager.getConnection("jdbc:ucanaccess://AdmissionOffice.accdb");
					String sql = "Select * from Faculty";
					PreparedStatement ps = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
					ResultSet rs = ps.executeQuery();
					rs.moveToInsertRow();
					rs.updateString("CMS", ((textField_1.getText())+(textField_9.getText())+(textField_10.getText())+(textField_12.getText())+(textField_13.getText()+(textField_15.getText())+(textField_16.getText())+(textField_17.getText())+(textField_18.getText()))));
					rs.updateString("Name",textField.getText() );
					rs.updateString("Department", comboBox_1.getSelectedItem()+"");
					rs.updateString("Qualification",textField_4.getText() );
					rs.updateString("FatherName",textField_2.getText() );
					rs.updateString("CNIC",textField_3.getText() );
					rs.updateString("Address",textField_5.getText() );
					rs.updateString("Contact",textField_7.getText() );
					rs.updateString("E-Mail",textField_7.getText() );
					rs.updateString("DateJoining",comboBox.getSelectedItem()+"/"+comboBox_1.getSelectedItem()+"/"+comboBox_2.getSelectedItem());
					String gen;
					if(radioButton.isSelected())
					{
						gen="male";
					}
					else
					{
						gen="female";
					}
					rs.updateString("Gender",gen);
					rs.updateString("Department",comboBox_3.getSelectedItem()+"");
					JOptionPane.showMessageDialog(null, "Thanks..");
					rs.insertRow();
					con.close();
					ps.close();
					HomePage h = new HomePage();
					frame.dispose();
				}
				catch(Exception d)
				{
					JOptionPane.showMessageDialog(null, d);
				}
			}
		});
	}

}
